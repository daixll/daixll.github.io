#include <iostream>
using namespace std;

int main(){
    string s;
    cin >> s;
    cout << s << endl;
    return 0;
}